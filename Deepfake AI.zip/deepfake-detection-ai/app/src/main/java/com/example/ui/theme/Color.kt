package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cybersecurity Dark Navy Palette
val CyberNavyDark = Color(0xFF070B19)
val CyberNavySurface = Color(0xFF0F172A)
val CyberNavyCard = Color(0xFF131D36)
val CyberNavyCardLight = Color(0xFF1E293B)
val CyberNavyBorder = Color(0xFF334155)

// Electric Accents
val NeonCyan = Color(0xFF00E5FF)
val NeonCyanGlow = Color(0x6600E5FF)
val NeonPurple = Color(0xFF9D4EDD)
val NeonViolet = Color(0xFF7928CA)
val NeonPink = Color(0xFFF72585)

// Status Colors
val VerdictRealGreen = Color(0xFF10B981)
val VerdictRealBg = Color(0xFF064E3B)
val VerdictFakeRed = Color(0xFFEF4444)
val VerdictFakeBg = Color(0xFF7F1D1D)
val VerdictInconclusiveAmber = Color(0xFFF59E0B)
val VerdictInconclusiveBg = Color(0xFF78350F)

// Text and Neutrals
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
