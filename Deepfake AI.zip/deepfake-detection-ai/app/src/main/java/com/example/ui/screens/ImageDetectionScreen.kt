package com.example.ui.screens

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AnalysisReport
import com.example.model.DetectionVerdict
import com.example.ui.components.ArtifactHeatmapOverlay
import com.example.ui.components.ConfidenceGauge
import com.example.ui.components.CyberCard
import com.example.ui.components.DisclaimerBanner
import com.example.ui.components.VerdictBadge
import com.example.ui.theme.CyberNavyDark
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VerdictFakeRed
import com.example.ui.viewmodel.AnalysisState
import com.example.ui.viewmodel.DetectionViewModel

@Composable
fun ImageDetectionScreen(
    viewModel: DetectionViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val selectedBitmap by viewModel.selectedImageBitmap.collectAsState()
    val fileName by viewModel.imageFileName.collectAsState()
    val fileSize by viewModel.imageFileSize.collectAsState()
    val analysisState by viewModel.imageAnalysisState.collectAsState()
    val showHeatmap by viewModel.showHeatmap.collectAsState()

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            var name = "uploaded_image.png"
            var size = 0L
            try {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val nIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val sIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                        if (nIdx != -1) name = cursor.getString(nIdx)
                        if (sIdx != -1) size = cursor.getLong(sIdx)
                    }
                }
            } catch (_: Exception) {}
            viewModel.onImageSelected(uri, name, size)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberNavyDark)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "IMAGE DEEPFAKE SCANNER",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            color = NeonCyan
        )
        Text(
            text = "Forensic Optical Analysis",
            fontSize = 20.sp,
            fontWeight = FontWeight.Black,
            color = TextPrimary
        )
        Spacer(modifier = Modifier.height(16.dp))

        // No image selected: Upload Card
        if (selectedBitmap == null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF0F172A))
                    .border(
                        width = 1.5.dp,
                        brush = Brush.linearGradient(listOf(NeonCyan.copy(alpha = 0.5f), NeonPurple.copy(alpha = 0.5f))),
                        shape = RoundedCornerShape(16.dp)
                    )
                    .clickable {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    }
                    .padding(24.dp)
                    .testTag("image_upload_target"),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(NeonCyan.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = "Select Image",
                            tint = NeonCyan,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Select Image to Analyze",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Accepts JPG, JPEG, PNG, WEBP (Max 25MB)",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = Color(0xFF04101A)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Browse Files", fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            // Image Preview Card with Heatmap Overlay
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Column {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black)
                    ) {
                        Image(
                            bitmap = selectedBitmap!!.asImageBitmap(),
                            contentDescription = "Selected Image Preview",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )

                        // If analysis completed with artifacts, display heatmap overlay
                        if (analysisState is AnalysisState.Success) {
                            val report = (analysisState as AnalysisState.Success).report
                            ArtifactHeatmapOverlay(
                                artifacts = report.artifacts,
                                showHeatmap = showHeatmap,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // File Metadata Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = fileName,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                maxLines = 1
                            )
                            val kb = fileSize / 1024
                            val sizeStr = if (kb > 1024) "%.1f MB".format(kb / 1024f) else "$kb KB"
                            Text(
                                text = "Size: $sizeStr • Resolution: ${selectedBitmap!!.width}x${selectedBitmap!!.height}",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }

                        if (analysisState !is AnalysisState.Analyzing) {
                            OutlinedButton(
                                onClick = {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Change", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Analysis Action / State Views
            when (val state = analysisState) {
                is AnalysisState.Idle -> {
                    Button(
                        onClick = { viewModel.analyzeSelectedImage() },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = Color(0xFF04101A)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("analyze_image_button")
                    ) {
                        Text(
                            text = "START FORENSIC ANALYSIS",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                    }
                }

                is AnalysisState.Analyzing -> {
                    CyberCard(
                        modifier = Modifier.fillMaxWidth(),
                        glowGradient = Brush.linearGradient(listOf(NeonCyan, NeonPurple))
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            val infiniteTransition = rememberInfiniteTransition(label = "pulse")
                            val pulseAlpha by infiniteTransition.animateFloat(
                                initialValue = 0.4f,
                                targetValue = 1f,
                                animationSpec = infiniteRepeatable(
                                    animation = tween(800, easing = LinearEasing),
                                    repeatMode = RepeatMode.Reverse
                                ),
                                label = "pulse"
                            )

                            Text(
                                text = "SCANNING IMAGE FORENSICS...",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp,
                                color = NeonCyan.copy(alpha = pulseAlpha)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = state.stepDescription,
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            LinearProgressIndicator(
                                progress = { state.progress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                                color = NeonCyan,
                                trackColor = Color(0xFF1E293B),
                            )
                        }
                    }
                }

                is AnalysisState.Success -> {
                    ImageResultsDashboard(
                        report = state.report,
                        showHeatmap = showHeatmap,
                        onToggleHeatmap = { viewModel.toggleHeatmap() },
                        onAnalyzeAnother = { viewModel.resetImageState() }
                    )
                }

                is AnalysisState.Error -> {
                    CyberCard(modifier = Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Error",
                                tint = VerdictFakeRed,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Analysis Error",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = VerdictFakeRed
                                )
                                Text(
                                    text = state.errorMessage,
                                    fontSize = 12.sp,
                                    color = TextSecondary
                                )
                            }
                            Button(
                                onClick = { viewModel.analyzeSelectedImage() },
                                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = Color.Black)
                            ) {
                                Text("Retry")
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        DisclaimerBanner()
        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun ImageResultsDashboard(
    report: AnalysisReport,
    showHeatmap: Boolean,
    onToggleHeatmap: () -> Unit,
    onAnalyzeAnother: () -> Unit
) {
    Column {
        // Results Card with Confidence Gauge and Verdict
        CyberCard(
            modifier = Modifier.fillMaxWidth(),
            glowGradient = Brush.linearGradient(
                when (report.verdict) {
                    DetectionVerdict.LIKELY_REAL -> listOf(Color(0xFF10B981).copy(alpha = 0.5f), NeonCyan.copy(alpha = 0.5f))
                    DetectionVerdict.LIKELY_MANIPULATED -> listOf(VerdictFakeRed.copy(alpha = 0.6f), NeonPurple.copy(alpha = 0.6f))
                    DetectionVerdict.INCONCLUSIVE -> listOf(Color(0xFFF59E0B).copy(alpha = 0.5f), NeonCyan.copy(alpha = 0.5f))
                }
            )
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "VERDICT CLASSIFICATION",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            color = NeonCyan
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        VerdictBadge(verdict = report.verdict, large = true)
                    }

                    ConfidenceGauge(
                        score = report.confidenceScore,
                        verdict = report.verdict,
                        sizeDp = 110
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Short explanation
                Text(
                    text = "Findings Summary",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = report.summaryExplanation,
                    fontSize = 12.sp,
                    color = TextSecondary,
                    lineHeight = 17.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Technical forensics
                Text(
                    text = "Technical Telemetry",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonCyan
                )
                Text(
                    text = report.technicalDetails,
                    fontSize = 11.sp,
                    color = TextMuted,
                    lineHeight = 15.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Heatmap Toggle Card (if artifacts detected)
        if (report.artifacts.isNotEmpty()) {
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Layers,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Artifact Heatmap Overlay",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "${report.artifacts.size} suspicious regions pinpointed",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    Switch(
                        checked = showHeatmap,
                        onCheckedChange = { onToggleHeatmap() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = NeonCyan,
                            checkedTrackColor = Color(0xFF0A3644),
                            uncheckedThumbColor = Color(0xFF64748B),
                            uncheckedTrackColor = Color(0xFF1E293B)
                        )
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Forensic Metric Telemetry Bars
        CyberCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Text(
                    text = "FORENSIC VECTOR TELEMETRY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = NeonCyan
                )
                Spacer(modifier = Modifier.height(12.dp))

                MetricBar(
                    label = "Error Level Disparity (ELA)",
                    score = report.metrics.elaDisparityScore,
                    description = "Measures JPEG 8x8 DCT recompression variance across quadrants."
                )
                Spacer(modifier = Modifier.height(10.dp))

                MetricBar(
                    label = "Sensor Noise Inconsistency",
                    score = report.metrics.noiseInconsistencyScore,
                    description = "Measures discrete Laplacian high-pass grain distribution."
                )
                Spacer(modifier = Modifier.height(10.dp))

                MetricBar(
                    label = "Boundary Inpainting Seams",
                    score = report.metrics.facialBoundaryArtifactScore,
                    description = "Evaluates gradient smoothing along silhouette edges."
                )
                Spacer(modifier = Modifier.height(10.dp))

                MetricBar(
                    label = "Color Chroma Gradient",
                    score = report.metrics.chromaGradientScore,
                    description = "Analyzes chrominance-luminance distortion."
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Analyze Another Button
        Button(
            onClick = onAnalyzeAnother,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B), contentColor = TextPrimary),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("analyze_another_image_button")
        ) {
            Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Analyze Another Image", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun MetricBar(
    label: String,
    score: Float,
    description: String
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary
            )
            Text(
                text = "%.1f%%".format(score),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (score > 60f) VerdictFakeRed else if (score < 40f) Color(0xFF10B981) else Color(0xFFF59E0B)
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { (score / 100f).coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = if (score > 60f) VerdictFakeRed else if (score < 40f) Color(0xFF10B981) else Color(0xFFF59E0B),
            trackColor = Color(0xFF0F172A),
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = description,
            fontSize = 10.sp,
            color = TextMuted
        )
    }
}
